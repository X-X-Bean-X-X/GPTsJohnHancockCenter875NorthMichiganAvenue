using System;using System.IO;using System.Linq;using System.Collections.Generic;using ChicagoBuildBridge;using Colossal.IO.AssetDatabase;using Game.Prefabs;using Newtonsoft.Json;using Newtonsoft.Json.Linq;using Unity.Entities;using Unity.Collections;using UnityEngine;
namespace ChicagoBuildExtensions{public static class Entry{public static object Run(BridgeSystem b,JObject c){
const string report=@"H:\Games\GPT, Chicago AI Project\ACM - Buildings\WIP\John Hancock Center\Validation\lighting-config.json";
if(File.Exists(report))throw new Exception("Lighting already configured; inspect report");
var ps=b.World.GetExistingSystemManaged<PrefabSystem>();var renders=new List<RenderPrefab>();
using(var q=b.EntityManager.CreateEntityQuery(ComponentType.ReadOnly<PrefabData>()))using(var es=q.ToEntityArray(Allocator.Temp))foreach(var e in es)if(ps.GetPrefabName(e).StartsWith("JohnHancockCenterXBeanXV2")){var p=ps.GetPrefab<PrefabBase>(e);if(p is RenderPrefab rp)renders.Add(rp);}
if(renders.Count!=3)throw new Exception("Three imported render prefabs required");
var rows=new List<object>();
foreach(var rp in renders){
if(rp.isPackaged||rp.Has<EmissiveProperties>())throw new Exception("Unconfigured editable render required");
var originals=rp.geometryAsset.ObtainMeshes(true);if(originals.Length!=1||originals[0].subMeshCount!=1)throw new Exception("Expected single source mesh");
var mesh=UnityEngine.Object.Instantiate(originals[0]);var vertices=mesh.vertices;var uv=mesh.uv;var indices=mesh.triangles;
var groups=Enumerable.Range(0,11).Select(_=>new List<int>()).ToArray();var areas=new double[10];
for(int i=0;i<indices.Length;i+=3){
int a=indices[i],d=indices[i+1],e=indices[i+2];var t=(uv[a]+uv[d]+uv[e])/3;int tile=(3-Math.Min(3,(int)(t.y*4)))*4+Math.Min(3,(int)(t.x*4));int g=0;
if(tile>=8&&tile<=12){
var lo=Vector3.Min(vertices[a],Vector3.Min(vertices[d],vertices[e]));var hi=Vector3.Max(vertices[a],Vector3.Max(vertices[d],vertices[e]));var center=(lo+hi)/2;
int floor=Math.Max(0,(int)((center.y-6)/3.2928f));
// Each LOD represents the same two-floor grouping; ten cycles balance occupancy.
int band=floor/2;float w=79.8576f+(48.768f-79.8576f)*Math.Min(1,center.y/335.28f);float depth=49.9872f+(30.48f-49.9872f)*Math.Min(1,center.y/335.28f);
bool wide=Math.Abs(center.z)/(depth/2)>Math.Abs(center.x)/(w/2);
float u=wide?center.x/(w/2):center.z/(depth/2);
int column=Math.Min(7,Math.Max(0,(int)((u+1)*4)));g=1+(band*3+column*7+(wide?0:3))%10;
areas[g-1]+=Vector3.Cross(vertices[d]-vertices[a],vertices[e]-vertices[a]).magnitude*.5;
}
groups[g].AddRange(new[]{a,d,e});}
if(groups.Any(x=>x.Count==0))throw new Exception("Empty lighting group");
mesh.subMeshCount=11;for(int g=0;g<11;g++)mesh.SetTriangles(groups[g],g,false);
mesh.RecalculateBounds();
var geometry=AssetDatabase.user.AddAsset<GeometryAsset,Mesh[]>(AssetDataPath.Create("X_Bean_X/JohnHancockCenterXBeanXV2",rp.name+"TenStageGeometry"),new[]{mesh});geometry.Save(true);
var surface=rp.surfaceAssets.Single();rp.geometryAsset=geometry;rp.surfaceAssets=Enumerable.Repeat(surface,11);rp.meshCount=11;
var ep=rp.AddOrGetComponent<EmissiveProperties>();ep.m_SingleLights=new List<EmissiveProperties.SingleLightMapping>();ep.m_AnimationCurves=new List<EmissiveProperties.AnimationProperties>();
for(int g=0;g<10;g++){
var keys=new List<Keyframe>();for(int stage=0;stage<=10;stage++){float value=((g-stage%10+10)%10)<5?1:0;keys.Add(new Keyframe(stage/10f,value,float.PositiveInfinity,float.PositiveInfinity));}
var curve=new AnimationCurve(keys.ToArray());curve.preWrapMode=WrapMode.Loop;curve.postWrapMode=WrapMode.Loop;
ep.m_AnimationCurves.Add(new EmissiveProperties.AnimationProperties{m_Duration=600,m_Curve=curve});
ep.m_SingleLights.Add(new EmissiveProperties.SingleLightMapping{materialId=g+1,purpose=EmissiveProperties.Purpose.DecorativeLight,previewState=true,color=new Color(1f,.86f,.64f,1),colorOff=Color.black,intensity=.18f,responseTime=0,animationIndex=g});}
rp.isDirty=true;rp.asset.MarkDirty();rp.asset.Save();ps.UpdatePrefab(rp);
var fractions=Enumerable.Range(0,10).Select(s=>Enumerable.Range(0,10).Where(g=>(g-s+10)%10<5).Sum(g=>areas[g])/areas.Sum()).ToArray();
rows.Add(new{name=rp.name,geometry=geometry.path,triangles=indices.Length/3,preservedTriangleCount=groups.Sum(g=>g.Count)==indices.Length,submeshes=11,windowAreaByGroup=areas,litAreaFractionByStage=fractions});}
ps.Update();var result=new{status="configured",author="X_Bean_X",stages=10,secondsPerStage=60,cycleSeconds=600,litGroupsPerStage=5,meshes=rows};File.WriteAllText(report,JsonConvert.SerializeObject(result,Formatting.Indented));return result;
}}}
