"""Original parametric John Hancock Center model. Author X_Bean_X.
Published overall dimensions; facade/roof details are reconstructed approximations.
Run with Blender 5.2 in background. Never reads or modifies another creator's mesh.
"""
import bpy,bmesh,math,json,shutil
import numpy as np
from pathlib import Path
from mathutils import Vector
from io_scene_fbx import parse_fbx
R=Path(__file__).resolve().parents[1]
for d in ['Source','Textures','Renders','Validation','ImportV001/JohnHancockCenterXBeanXV1']:(R/d).mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
scene['author']='X_Bean_X';scene['building']='John Hancock Center / 875 North Michigan Avenue'
scene['model_note']='Original reconstruction; published envelope dimensions, approximate facade and roof equipment.'
W,D,H=79.8576,49.9872,343.7
WT,DT=48.768,30.48
# Original 4x4 atlas, deliberately no photographic pixels.
palette=[(25,29,32),(45,55,61),(72,79,83),(121,125,126),
         (98,102,104),(20,24,27),(170,158,127),(179,184,186),
         (38,46,51),(49,60,67),(61,72,79),(32,39,44),
         (116,107,87),(81,85,86),(31,34,36),(197,159,86)]
S=1024;T=256;rng=np.random.default_rng(875)
arrays={k:np.zeros((S,S,4),dtype=np.float32) for k in ['BaseColor','MaskMap','Normal','ControlMask']}
arrays['Normal'][:]=[.5,.5,1,1]
for i,col in enumerate(palette):
    x=i%4*T;y=(3-i//4)*T
    noise=rng.normal(0,.7,(T,T,1))/255
    arrays['BaseColor'][y:y+T,x:x+T,:3]=np.clip(np.array(col)/255+noise,0,1)
    arrays['BaseColor'][y:y+T,x:x+T,3]=1
    arrays['MaskMap'][y:y+T,x:x+T,0]=.75 if i in [0,2,7,14] else .25
    arrays['MaskMap'][y:y+T,x:x+T,3]=.76 if i in [1,8,9,10,11] else .34
    arrays['MaskMap'][y:y+T,x:x+T,2]=.24 if i==15 else 0
for suffix,arr in arrays.items():
    im=bpy.data.images.new('JHC_'+suffix,width=S,height=S,alpha=True)
    im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color'
    im.pixels.foreach_set(arr.reshape(-1));im.filepath_raw=str(R/'Textures'/('JHC_'+suffix+'.png'));im.file_format='PNG';im.save()
mat=bpy.data.materials.new('X_Bean_X_Hancock_Atlas');mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF')
tex=mat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images['JHC_BaseColor'];mat.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color'])
bs.inputs['Metallic'].default_value=.45;bs.inputs['Roughness'].default_value=.36
class Mesh:
    def __init__(self,name):self.name=name;self.v=[];self.f=[];self.m=[]
    def face(self,pts,m):
        n=len(self.v);self.v.extend(pts);self.f.append(tuple(range(n,n+len(pts))));self.m.append(m)
    def box(self,c,s,m):
        x,y,z=c;a,b,d=[v/2 for v in s]
        p=[(x+i*a,y+j*b,z+k*d) for i,j,k in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
        for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:self.face([p[i] for i in ids],m)
    def beam(self,a,b,width,depth,m):
        a,b=Vector(a),Vector(b);z=(b-a).normalized();x=z.cross(Vector((0,0,1)))
        if x.length<.01:x=z.cross(Vector((0,1,0)))
        x.normalize();y=z.cross(x).normalized()
        p=[tuple(c+x*i*width/2+y*j*depth/2) for c in [a,b] for i,j in [(-1,-1),(1,-1),(1,1),(-1,1)]]
        for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:self.face([p[i] for i in ids],m)
    def rod(self,a,b,r,m,n=8):
        a,b=Vector(a),Vector(b);z=(b-a).normalized();x=z.cross(Vector((0,1,0))).normalized();y=z.cross(x)
        rows=[[tuple(c+r*(x*math.cos(i*math.tau/n)+y*math.sin(i*math.tau/n))) for i in range(n)] for c in [a,b]]
        for i in range(n):self.face([rows[0][i],rows[0][(i+1)%n],rows[1][(i+1)%n],rows[1][i]],m)
        self.face(rows[0][::-1],m);self.face(rows[1],m)
    def finish(self):
        me=bpy.data.meshes.new(self.name);me.from_pydata(self.v,[],self.f);me.materials.append(mat);me.update();uv=me.uv_layers.new()
        for p,mi in zip(me.polygons,self.m):
            for j,l in enumerate(p.loop_indices):uv.data[l].uv=((mi%4+.1+(j in [1,2])*.8)/4,(3-mi//4+.1+(j>=2)*.8)/4)
        bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free()
        o=bpy.data.objects.new(self.name,me);scene.collection.objects.link(o);o['author']='X_Bean_X';return o
def wh(z):
    t=max(0,min(1,z/335.28));return W+(WT-W)*t,D+(DT-D)*t
def point(side,u,z,out=0):
    w,d=wh(z)
    if side==0:return (u*w/2,-d/2-out,z)
    if side==1:return (w/2+out,u*d/2,z)
    if side==2:return (-u*w/2,d/2+out,z)
    return (-w/2-out,-u*d/2,z)
def build(lod):
    body=Mesh('JohnHancockCenterXBeanXV1'+(f'_LOD{lod}' if lod else ''))
    # Granite apron and recessed arcade; tower envelope begins at ground.
    body.box((0,0,.22),(94,62,.44),4)
    body.box((0,0,1.1),(84,54,1.3),5)
    body.box((0,0,3.8),(79.6,49.7,5.4),1)
    floors=100 if lod<2 else 50
    for side in range(4):
        cols=(32 if side%2==0 else 20) if lod==0 else (16 if side%2==0 else 10) if lod==1 else (8 if side%2==0 else 5)
        for f in range(floors):
            z0=6+f*(329.28/floors);z1=6+(f+1)*(329.28/floors)
            for k in range(cols):
                u0=-1+2*k/cols;u1=-1+2*(k+1)/cols
                mi=[8,9,10,11][(f*13+k*7+side*3)%4]
                if lod==0 and f>45 and (f*17+k*11+side)%23==0:mi=12
                body.face([point(side,u0,z0),point(side,u1,z0),point(side,u1,z1),point(side,u0,z1)],mi)
            # Repeated dark spandrels remain readable in all LODs.
            body.beam(point(side,-1,z0,.08),point(side,1,z0,.08),.2,.50 if lod<2 else .75,0)
        if lod<2:
            for k in range(cols+1):
                u=-1+2*k/cols
                body.beam(point(side,u,6,.1),point(side,u,335.28,.1),.18 if lod==0 else .26,.18,0)
        # Five 20-storey tiers. Wide elevations have two structural bays.
        bays=2 if side%2==0 else 1
        for tier in range(5):
            z0=6+tier*65.856;z1=6+(tier+1)*65.856
            body.beam(point(side,-1,z0,.45),point(side,1,z0,.45),.9,1.0,0)
            for j in range(bays):
                u0=-1+2*j/bays;u1=-1+2*(j+1)/bays
                for a,b in [(u0,u1),(u1,u0)]:body.beam(point(side,a,z0,.5),point(side,b,z1,.5),1.05,.7,0)
        for u in np.linspace(-1,1,5 if side%2==0 else 3):
            body.beam(point(side,float(u),1,.40),point(side,float(u),335.28,.40),1.05,.9,0)
        # Black mechanical crown and observation band.
        body.face([point(side,-1,335.28),point(side,1,335.28),point(side,1,343.7),point(side,-1,343.7)],0)
        if lod<2:
            for z in np.arange(336,343.4,.65):body.beam(point(side,-1,z,.12),point(side,1,z,.12),.12,.18,2)
        # Ground glazing and projecting entrance canopy.
        for u in [-.55,0,.55]:
            body.beam(point(side,u,0,.7),point(side,u,5.5,.7),.2,.2,7)
    body.box((0,0,343.35),(WT,DT,.7),0)
    # Roof plant boxes, parapet and antenna bases; detail placement approximate.
    for x in [-14,14]:
        body.box((x,0,346.1),(6.5,6.5,4.8),0)
        for z0,z1,r,mi in [(348.5,378,1.35,3),(378,411,1.0,7),(411,438,.65,7),(438,456.9,.30,3)]:
            body.rod((x,0,z0),(x,0,z1),r,mi,8 if lod<2 else 6)
        if lod<2:
            for z in np.arange(350,452,6):body.rod((x,0,z),(x,0,z+.5),1.6 if z<378 else 1.15 if z<411 else .75,0)
            for yy in [-2.6,2.6]:body.beam((x,yy,344),(x,0,358),.20,.20,3)
        body.box((x,0,456.65),(.75,.75,.5),15)
    for x in [-6,6]:
        for y in [-8,8]:body.box((x,y,345),(7,4,2.6),13)
    # Canopies front/back. +Y faces the native street after FBX conversion.
    for y in [-27,27]:
        body.box((0,y,5.8),(18,7,.45),2)
        for x in [-8,8]:body.box((x,y,2.9),(.35,.35,5.8),7)
    if lod==0:
        for x in [-44,44]:
            for y in [-22,-10,10,22]:body.box((x,y,.8),(2.5,5,1.2),4)
    return body.finish()
objs=[build(i) for i in range(3)]
for i,o in enumerate(objs):o.hide_render=i!=0;o.hide_set(i!=0)
scene.world=bpy.data.worlds.new('Studio');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.48,.55,.64,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.7
bpy.ops.object.light_add(type='SUN');bpy.context.object.data.energy=3;bpy.context.object.rotation_euler=(.65,-.35,-.6);bpy.context.object.data.angle=.12
bpy.ops.object.camera_add(location=(650,-850,500));cam=bpy.context.object;scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=510;cam.data.clip_end=5000
def aim(p):cam.rotation_euler=(Vector(p)-cam.location).to_track_quat('-Z','Y').to_euler()
aim((0,0,225))
scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=True
try:
    prefs=bpy.context.preferences.addons['cycles'].preferences;prefs.compute_device_type='OPTIX';prefs.get_devices()
    for dev in prefs.devices:dev.use=dev.type=='OPTIX'
    if any(dev.type=='OPTIX' for dev in prefs.devices):scene.cycles.device='GPU'
except Exception:pass
scene.render.resolution_x=1200;scene.render.resolution_y=1500;scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX'
scene.render.image_settings.file_format='PNG'
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Source/X_Bean_X_JohnHancockCenter_v001.blend'))
reports=[]
for lod,o in enumerate(objs):
    o.hide_set(False);bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
    tri=o.modifiers.new('Triangles','TRIANGULATE');bpy.ops.object.modifier_apply(modifier=tri.name)
    dest=R/'ImportV001/JohnHancockCenterXBeanXV1';path=dest/(o.name+'.fbx')
    bpy.ops.export_scene.fbx(filepath=str(path),use_selection=True,object_types={'MESH'},axis_forward='-Z',axis_up='Y',bake_space_transform=True,apply_unit_scale=True,apply_scale_options='FBX_SCALE_NONE',mesh_smooth_type='FACE',use_tspace=True,bake_anim=False,add_leaf_bones=False,use_custom_props=True)
    pts=np.array([v.co[:] for v in o.data.vertices]);bm=bmesh.new();bm.from_mesh(o.data);deg=sum(f.calc_area()<1e-9 for f in bm.faces);bm.free()
    reports.append({'lod':lod,'file':path.name,'triangles':len(o.data.polygons),'vertices':len(o.data.vertices),'boundsMin':pts.min(0).tolist(),'boundsMax':pts.max(0).tolist(),'degenerateFaces':deg,'finite':bool(np.isfinite(pts).all()),'uv':bool(o.data.uv_layers)})
    for suffix in arrays:shutil.copy2(R/'Textures'/('JHC_'+suffix+'.png'),dest/(o.name+'_'+suffix+'.png'))
    o.hide_set(lod!=0)
(R/'Validation/mesh-export.json').write_text(json.dumps({'author':'X_Bean_X','meshes':reports},indent=2))
scene.render.filepath=str(R/'Renders/v001_southeast.png');bpy.ops.render.render(write_still=True)
cam.location=(0,-850,210);aim((0,0,225));scene.render.filepath=str(R/'Renders/v001_elevation.png');bpy.ops.render.render(write_still=True)
print('HANCOCK_BUILD_COMPLETE '+json.dumps(reports),flush=True)

