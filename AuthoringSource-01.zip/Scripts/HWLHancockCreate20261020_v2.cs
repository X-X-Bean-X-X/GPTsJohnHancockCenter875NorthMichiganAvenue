using System;using System.IO;using System.Linq;using System.Collections.Generic;using ChicagoBuildBridge;using Colossal;using Colossal.UI;using Colossal.IO.AssetDatabase;using Game.Prefabs;using Game.Prefabs.Effects;using Newtonsoft.Json.Linq;using Unity.Collections;using Unity.Entities;using Unity.Mathematics;using UnityEngine;
namespace ChicagoBuildExtensions{public static class Entry{public static object Run(BridgeSystem b,JObject c){
var ps=b.World.GetExistingSystemManaged<PrefabSystem>();RenderPrefab mesh=null;
using(var q=b.EntityManager.CreateEntityQuery(ComponentType.ReadOnly<PrefabData>()))using(var es=q.ToEntityArray(Allocator.Temp))foreach(var e in es){
var n=ps.GetPrefabName(e);if(n=="JohnHancockCenterXBeanXV2")throw new Exception("Already exists");if(n=="JohnHancockCenterXBeanXV2 Mesh")mesh=ps.GetPrefab<RenderPrefab>(e);}
if(mesh==null)throw new Exception("Imported mesh missing");
if(!ps.TryGetPrefab(new PrefabID("BuildingPrefab","NA_MixedSignature03"),out var source))throw new Exception("Base mixed-use template missing");
if(!ps.TryGetPrefab(new PrefabID("BuildingPrefab","CN_ModernLibrary"),out var lib))throw new Exception("Pedestrian entry template missing");
if(!ps.TryGetPrefab(new PrefabID("EffectPrefab","GardenLightSource03"),out var originalLight))throw new Exception("Base light missing");
const string folder="X_Bean_X/JohnHancockCenterXBeanXV2";
var light=PrefabBase.Create<EffectPrefab>("XBeanXHancockEntranceLightV2");light.m_Conditions=((EffectPrefab)originalLight).m_Conditions;light.m_DisableDistanceCulling=false;
foreach(var co in originalLight.components)light.AddComponentFrom(co);
var le=light.GetComponent<LightEffect>();le.m_Range=10;le.m_ColorTemperature=3200;le.m_LightDimmer=1;le.m_UseVolumetric=false;
var la=AssetDatabase.user.AddAsset(AssetDataPath.Create(folder,light.name),light);la.Save();ps.AddPrefab(light);
var p=PrefabBase.Create<BuildingPrefab>("JohnHancockCenterXBeanXV2");
var allowed=new HashSet<string>{"BuildingProperties","SignatureBuilding","UIObject","Attraction","Pollution"};
foreach(var co in source.components)if(allowed.Contains(co.GetType().Name))p.AddComponentFrom(co);
p.m_LotWidth=12;p.m_LotDepth=8;p.m_AccessType=((BuildingPrefab)source).m_AccessType;
p.m_Meshes=new[]{new ObjectMeshInfo{m_Mesh=mesh,m_Position=float3.zero,m_Rotation=quaternion.identity}};
p.GetComponent<BuildingProperties>().m_ResidentialProperties=703;
p.GetComponent<BuildingProperties>().m_SpaceMultiplier=1.3f;
p.GetComponent<Attraction>().m_Attractiveness=80;
var entry=lib.GetComponent<ObjectSubObjects>().m_SubObjects.Single(x=>x.m_Object.Has<SpawnLocation>());
entry.m_Position=new float3(0,0,31.7f);entry.m_Rotation=quaternion.RotateY(math.PI);entry.m_ParentMesh=0;entry.m_GroupIndex=0;entry.m_Probability=100;
p.AddOrGetComponent<ObjectSubObjects>().m_SubObjects=new[]{entry};
var unlock=p.AddOrGetComponent<Unlockable>();unlock.m_RequireAll=new PrefabBase[0];unlock.m_RequireAny=new PrefabBase[0];unlock.m_IgnoreDependencies=true;
p.AddOrGetComponent<ObsoleteIdentifiers>().m_PrefabIdentifiers=new[]{new PrefabIdentifierInfo{m_Type="BuildingPrefab",m_Name=p.name}};
var fx=p.AddOrGetComponent<EffectSource>();fx.m_Effects=new List<EffectSource.EffectSettings>();
foreach(float x in new[]{-7f,0f,7f})fx.m_Effects.Add(new EffectSource.EffectSettings{m_Effect=light,m_PositionOffset=new float3(x,5.5f,28),m_ParentMesh=-1,m_Intensity=1});
var icon=ImageAsset.ImportImageFromPath(@"H:\Games\GPT, Chicago AI Project\ACM - Buildings\WIP\John Hancock Center\Renders\v002_southeast.png");icon.Load(true);
p.GetComponent<UIObject>().m_Icon=icon.ToGlobalUri();p.GetComponent<UIObject>().m_Priority=875;
p.GetComponent<SignatureBuilding>().m_UnlockEventImage=icon.ToGlobalUri();
p.AddOrGetComponent<Localization>().m_LocalizationID="Assets.NAME["+p.name+"]";
var a=AssetDatabase.user.AddAsset(AssetDataPath.Create(folder,p.name),p);a.Save();ps.AddPrefab(p);ps.Update();
var loc=AssetDatabase.user.AddAsset<LocaleAsset>(AssetDataPath.Create(folder,"en-US"));
var strings=new Dictionary<string,string>{{"Assets.NAME["+p.name+"]","GPT's John Hancock Center"},{"Assets.DESCRIPTION["+p.name+"]","Original John Hancock Center reconstruction by X_Bean_X. 343.7 m architectural height, 456.9 m antenna tip. Mixed residential and commercial signature building; 703 households. Approximate facade and roof details. 12 x 8 cells."}};
loc.SetData(new LocaleData("en-US",strings,new Dictionary<string,int>()),SystemLanguage.English,"English");loc.Save();Game.SceneFlow.GameManager.instance.localizationManager.AddSource("en-US",loc);
return new{status="created",author="X_Bean_X",asset=a.path,mesh=mesh.name,lot=new[]{12,8},households=703,icon=icon.ToGlobalUri(),lights=3};
}}}
